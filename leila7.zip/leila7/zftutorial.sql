-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 03, 2020 at 12:52 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zftutorial`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
CREATE TABLE IF NOT EXISTS `album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artist` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=182 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`id`, `artist`, `title`) VALUES
(104, 'Fun.', 'aaaaaaaa'),
(165, 'hiddd  Art bidad', 'hiddd'),
(167, '2  Art bidad', '2'),
(170, 'hg  Art bidad', 'hg'),
(171, 'hello  Art bidad', 'hello'),
(172, 'hello  Art bidad', 'hello'),
(173, 'ngggg  Art bidad', 'ngggg'),
(174, 'wqq  Art bidad', 'wqq'),
(176, 'deeeee  Art bidad', 'deeeee'),
(177, 'sssss  Art bidad', 'sssss'),
(178, 'ADELE  Art bidad', 'ADELE'),
(179, 'ewww  Art bidad', 'ewww'),
(180, 'wq  Art bidad', 'wq'),
(181, '21  Art bidad', '21');

-- --------------------------------------------------------

--
-- Table structure for table `instrument`
--

DROP TABLE IF EXISTS `instrument`;
CREATE TABLE IF NOT EXISTS `instrument` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(68) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `price` int(11) NOT NULL,
  `volume` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `instrument`
--

INSERT INTO `instrument` (`id`, `company`, `price`, `volume`) VALUES
(1, 'ایران تجارت', 100000, 2147483647),
(2, 'ایران مال', 200000, 1149),
(3, 'LG', 300000, 555168),
(4, 'Lorex', 400000, 1032223324),
(5, 'کورش', 42000, 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `leilafilter`
--

DROP TABLE IF EXISTS `leilafilter`;
CREATE TABLE IF NOT EXISTS `leilafilter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(68) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `instrument_id` int(11) NOT NULL,
  `order_date` timestamp NOT NULL,
  `order_value` varchar(68) COLLATE utf8_persian_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `type_id`, `instrument_id`, `order_date`, `order_value`, `user_id`) VALUES
(88, 2, 4, '2019-12-31 11:27:38', '32323', 3),
(89, 1, 4, '2019-12-31 11:35:23', '477777777', 3),
(90, 2, 4, '2019-12-31 11:35:36', '30000000', 3),
(91, 2, 1, '2019-12-31 11:35:38', '30000000', 3),
(92, 1, 1, '2019-12-31 11:35:58', '30000000', 3),
(93, 1, 1, '2019-12-31 11:36:17', '30000000', 3),
(94, 1, 1, '2019-12-31 11:36:36', '30000000', 3),
(95, 2, 1, '2019-12-31 11:40:31', '30000000', 3),
(96, 2, 1, '2019-12-31 11:40:46', '30000000', 3),
(97, 1, 1, '2019-12-31 11:40:53', '30001100', 3),
(98, 1, 4, '2019-12-31 12:17:40', '322222', 3),
(99, 1, 1, '2020-01-01 06:18:36', '30000000', 3),
(100, 1, 1, '2019-12-31 11:27:38', '6566', 1),
(101, 1, 1, '2019-12-31 11:27:38', '55555', 1),
(102, 1, 1, '2019-12-31 11:27:38', '46546', 1),
(103, 1, 1, '2019-12-31 11:27:38', '65656', 1),
(104, 1, 1, '2019-12-31 11:27:38', '545646', 1),
(105, 1, 1, '2020-01-03 05:45:01', '65456', 1),
(106, 1, 1, '2020-01-03 05:45:13', '56456', 1),
(107, 1, 1, '2020-01-03 05:45:53', '555555', 1),
(108, 1, 1, '2020-01-03 05:46:20', '564654', 1),
(109, 1, 1, '2020-01-03 05:47:26', '54654', 1),
(110, 1, 1, '2020-01-03 05:47:43', '54564', 1),
(111, 1, 1, '2020-01-03 05:48:46', '555', 1),
(112, 1, 1, '2020-01-03 05:49:12', '555', 1),
(113, 1, 1, '2020-01-03 05:49:14', '555', 1),
(114, 1, 2, '2020-01-03 06:20:20', '23232', 1),
(115, 1, 2, '2020-01-03 06:33:17', '12222', 1),
(116, 1, 2, '2020-01-03 06:35:41', '13231', 1),
(117, 1, 5, '2020-01-03 07:29:39', '12111', 1),
(118, 2, 3, '2020-01-03 07:29:59', '123', 1),
(119, 1, 1, '2020-01-03 08:06:40', '322', 1),
(120, 2, 1, '2020-01-03 08:06:56', '21212', 1),
(121, 2, 3, '2020-01-03 08:06:57', '434343', 1),
(122, 1, 1, '2020-01-03 08:28:26', '23232', 1),
(123, 1, 1, '2020-01-03 08:28:39', '21212', 1),
(124, 1, 1, '2020-01-03 08:36:25', '23232', 1),
(125, 2, 1, '2020-01-03 08:36:46', '555', 1),
(126, 1, 5, '2020-01-03 08:37:54', '21212', 1),
(127, 1, 1, '2020-01-03 08:44:28', '23232', 1),
(128, 1, 4, '2020-01-03 08:45:06', '12333333333333', 1),
(129, 1, 1, '2020-01-03 08:48:02', '232', 1),
(130, 2, 2, '2020-01-03 09:19:43', '2323232', 1),
(131, 1, 2, '2020-01-03 09:20:02', '23232', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_types`
--

DROP TABLE IF EXISTS `order_types`;
CREATE TABLE IF NOT EXISTS `order_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(68) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `order_types`
--

INSERT INTO `order_types` (`id`, `type_name`) VALUES
(1, 'خرید'),
(2, 'فروش');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `product_id` int(20) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(120) NOT NULL,
  `product_brand` varchar(100) NOT NULL,
  `product_price` decimal(8,2) NOT NULL,
  `product_ram` char(5) NOT NULL,
  `product_storage` varchar(50) NOT NULL,
  `product_camera` varchar(20) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `product_quantity` mediumint(5) NOT NULL,
  `product_status` enum('0','1') NOT NULL COMMENT '0-active,1-inactive',
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_brand`, `product_price`, `product_ram`, `product_storage`, `product_camera`, `product_image`, `product_quantity`, `product_status`) VALUES
(1, 'Honor 9 Lite (Sapphire Blue, 64 GB)  (4 GB RAM)', 'Honor', '14499.00', '4', '64', '13', 'image-1.jpeg', 10, '1'),
(2, '\r\nInfinix Hot S3 (Sandstone Black, 32 GB)  (3 GB RAM)', 'Infinix', '8999.00', '3', '32', '13', 'image-2.jpeg', 10, '1'),
(3, 'VIVO V9 Youth (Gold, 32 GB)  (4 GB RAM)', 'VIVO', '16990.00', '4', '32', '16', 'image-3.jpeg', 10, '1'),
(4, 'Moto E4 Plus (Fine Gold, 32 GB)  (3 GB RAM)', 'Moto', '11499.00', '3', '32', '8', 'image-4.jpeg', 10, '1'),
(5, 'Lenovo K8 Plus (Venom Black, 32 GB)  (3 GB RAM)', 'Lenevo', '9999.00', '3', '32', '13', 'image-5.jpg', 10, '1'),
(6, 'Samsung Galaxy On Nxt (Gold, 16 GB)  (3 GB RAM)', 'Samsung', '10990.00', '3', '16', '13', 'image-6.jpeg', 10, '1'),
(7, 'Moto C Plus (Pearl White, 16 GB)  (2 GB RAM)', 'Moto', '7799.00', '2', '16', '8', 'image-7.jpeg', 10, '1'),
(8, 'Panasonic P77 (White, 16 GB)  (1 GB RAM)', 'Panasonic', '5999.00', '1', '16', '8', 'image-8.jpeg', 10, '1'),
(9, 'OPPO F5 (Black, 64 GB)  (6 GB RAM)', 'OPPO', '19990.00', '6', '64', '16', 'image-9.jpeg', 10, '1'),
(10, 'Honor 7A (Gold, 32 GB)  (3 GB RAM)', 'Honor', '8999.00', '3', '32', '13', 'image-10.jpeg', 10, '1'),
(11, 'Asus ZenFone 5Z (Midnight Blue, 64 GB)  (6 GB RAM)', 'Asus', '29999.00', '6', '128', '12', 'image-12.jpeg', 10, '1'),
(12, 'Redmi 5A (Gold, 32 GB)  (3 GB RAM)', 'MI', '5999.00', '3', '32', '13', 'image-12.jpeg', 10, '1'),
(13, 'Intex Indie 5 (Black, 16 GB)  (2 GB RAM)', 'Intex', '4999.00', '2', '16', '8', 'image-13.jpeg', 10, '1'),
(14, 'Google Pixel 2 XL (18:9 Display, 64 GB) White', 'Google', '61990.00', '4', '64', '12', 'image-14.jpeg', 10, '1');

-- --------------------------------------------------------

--
-- Table structure for table `uins`
--

DROP TABLE IF EXISTS `uins`;
CREATE TABLE IF NOT EXISTS `uins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `instrument_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uins`
--

INSERT INTO `uins` (`id`, `user_id`, `instrument_id`, `quantity`) VALUES
(240, 3, 1, 28),
(241, 3, 2, 11),
(242, 3, 3, 13),
(243, 3, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(68) NOT NULL,
  `password` varchar(68) NOT NULL,
  `amount` int(11) NOT NULL,
  `phone` varchar(68) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `amount`, `phone`) VALUES
(1, 'leila', '20122012', -86213, ''),
(2, 'sima', '12345', 14044, ''),
(3, 'amir@amir.com', '123456', -2147483634, ''),
(4, 'leilabidad@gmail.com', '20122012', 0, ''),
(5, 'amir11@amir.com', '123456', 0, ''),
(6, 'ami444r@amir.com', '123456', 0, ''),
(7, 'amir123@amir.com', '123456', 0, ''),
(8, 'am877ir@amir.com', '123456', 0, ''),
(9, 'a12mir@amir.com', '123456', 0, ''),
(10, 'amir@21amir.com', '123456', -545454, ''),
(11, 'am2121ir@amir.com', '123456', 0, ''),
(12, 'shohre@gmail.com', '123457', 234245, ''),
(13, 'hooman', '123456', 3274, ''),
(14, 'hs', '123456', 0, ''),
(15, 'amir@ak,mir.com', '123456', 0, ''),
(16, 'am23232ir@amir.com', '123456', 0, ''),
(17, 'shahla', '123456', 0, ''),
(18, 'amir@am2222ir.com', '123456', 0, ''),
(19, 'amir@amierwewr.com', '123456', 0, ''),
(20, 'am33ir@amir.com', '123456', 0, ''),
(21, 'am11111ir@amir.com', '123456', 0, ''),
(22, 'amir@22222amir.com', '123456', 0, ''),
(23, 'amir@am2323ir.com', '123456', 0, ''),
(24, 'amir@a2222mir.com', '123456', 0, ''),
(25, 'amir@am444ir.com', '123456', 0, ''),
(26, 'amir@amir.3333com', '123456', 0, ''),
(27, 'amir@awewewewemir.com', '', 0, ''),
(28, '', '123456', 0, ''),
(29, 'amir@amثققققir.com', '123456', 0, ''),
(30, 'amir@amبلبلبلبir.com', '123456', 0, '3423424ببقب-غاف 786700988'),
(31, 'leili', '123456', 0, '123 2544 78787 7888'),
(32, '211111@amir.com', '123456', 0, 'sass dewewe'),
(33, 'am444ir@amir.com', '123456', 0, '0 (042) 342-4242'),
(34, 'aفففففmir@amir.com', '123456', 0, '3 (424) 444-4444'),
(35, 'amir4444@amir.com', '123456', 0, '3 (423) 424-7867'),
(36, 'amir@am222222ir.com', '123456', 0, '3 (423) 424-7867'),
(37, 'amir@333amir.com', '123456', 0, '0 (007) 474-4525'),
(38, 'amir@agdgdmir.com', '12345675', 0, '5 (454) 545-6445'),
(39, '115ممممممممثهمه', '20122012', 0, '1 (546) 548-5654');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `pass_word` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `pass_word`) VALUES
(1, 'samsonasik', 'e10adc3949ba59abbe56e057f20f883e');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
