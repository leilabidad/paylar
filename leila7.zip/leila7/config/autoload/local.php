<?php
use Doctrine\DBAL\Driver\PDOMySql\Driver as PDOMySqlDriver;

return [
    'doctrine' => [
        'connection' => [
            'orm_default' => [
                'driverClass' => PDOMySqlDriver::class,
                'params' => [
                    'host'     => 'localhost',
                    'user'     => 'root',
                    'password' => '',
                    'dbname'   => 'zftdfgdfdutorial',
                    'port'     => '3306',
					'driver_options' => [
            1002 => 'SET NAMES \'UTF8\'',
        ],

                ]
            ],
        ],
        'driver' => [
            'Doctrine_driver' => [
                'class' => \Doctrine\ORM\Mapping\Driver\AnnotationDriver::class,
                'cache' => 'array',
                'paths' => [
                    __DIR__ . '/../../module/Album/src/Entity',
                    __DIR__ . '/../../module/User/src/Entity',
                ],

            ],
            'orm_default' => [
                'drivers' => [
                    'Album\\Entity' => 'Doctrine_driver',
                    'User\\Entity' => 'Doctrine_driver',
                ],
            ],
        ],
    ],
];