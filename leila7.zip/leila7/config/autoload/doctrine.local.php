<?php
/**
 * Created by PhpStorm.
 * User: Amir
 * Date: 12/1/2019
 * Time: 1:03 PM
 */
use Doctrine\DBAL\Driver\PDOMySql\Driver as PDOMySqlDriver;

return [
    'doctrine' => [
        'connection' => [
            'orm_default' => [
                'driverClass' => PDOMySqlDriver::class,
                'params' => [
                    'host'     => 'localhost',
                    'user'     => 'root',
                    'password' => '',
                    'dbname'   => 'zftutorial',
                    'port'     => '3306',
                    'driverOptions' => [
                        1002=>'SET NAMES utf8',
                    ]
                ]
            ],
        ],
        'driver' => [
            'Doctrine_driver' => [
                'class' => \Doctrine\ORM\Mapping\Driver\AnnotationDriver::class,
                'cache' => 'array',
                'paths' => [
                    __DIR__ . '/../../module/Album/src/Entity',
                    __DIR__ . '/../../module/Uins/src/Entity',
                    __DIR__ . '/../../module/User/src/Entity',
                ],
            ],
            'orm_default' => [
                'drivers' => [
                    'Album\\Entity' => 'Doctrine_driver',
                    'Uins\\Entity' => 'Doctrine_driver',
                    'User\\Entity' => 'Doctrine_driver',
                ],
            ],
        ],
    ],
];