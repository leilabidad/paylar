app.directive("uinsHeader", function() {
    return {
        template: '<h3 style="padding: 20px">{{header.title}}</h3>'
    };
});

app.directive("uinsPriceslider", function() {
    return {
        template: '<p><input ng-model="fromToValue" ng-change="numberToSlider()" style="width:100%"  type="range" min="0" max="8000"  step="5" ></p>'
    };
});

app.directive("uinsPrice", function() {
    return {
        template: '<p style="text-align: center;">رنج قیمت از صفر تا {{fromToValue}}</p>'
    };
});

app.directive("uinsListheader", function() {
    return {
        template: '<li  class="w3-padding-16" style="line-height:0.5;font-weight:bold;"><div class="w3-col s3"><span style="cursor:pointer;" class="w3-left w3-margin-left">حذف</span><span style="cursor:pointer;" class="w3-left w3-margin-left"> ویرایش /</span><span>تاریخ</span></div><div class="w3-col s3" >مبلغ سفارش</div><div class="w3-col s3">نام شرکت</div><div class="w3-col s1">نوع سفارش</div><div class="w3-col s1" >شناسه</div><div class="w3-col s1">ردیف</div></li>'
    };
});

app.directive("uinsListcounter", function() {
    return {
        template: '<div class="w3-col s1">{{$index+1}} - </div>'
    };
});

app.directive("uinsListorderid", function() {
    return {
        template: '<div class="w3-col s1" >{{x.order_id}}</div>'
    };
});

app.directive("uinsListypename", function() {
    return {
        template: '<div class="w3-col s1">{{x.type_name}}</div>'
    };
});


app.directive("uinsListinstrumentname", function() {
    return {
        template: '<div class="w3-col s3">{{x.instrument_name}}</div>'
    };
});

app.directive("uinsListprice", function() {
    return {
        template: '<div class="w3-col s3"><span ng-click="editThisPrice($index)" style="cursor:pointer;" class="w3-left w3-margin-left">ویرایش مبلغ</span>{{x.order_value}}</div>'
    };
});

app.directive("uinsListedit", function() {
    return {
        template: '<div class="w3-col s3">{{x.order_date}}<span ng-click="removeItem($index)" style="cursor:pointer;" class="w3-left w3-margin-left">×</span><span ng-click="editThisItem($index)" style="cursor:pointer;" class="w3-left w3-margin-left">ویرایش</span></div>'
    };
});

app.directive("uinsEditpriceform", function() {
    return {
        template: '<div id="editPriceForm" style="display:none;" class="w3-container w3-light-grey w3-padding-16"><div class="w3-row w3-margin-top"><div class="w3-col s6"><button ng-click="editPriceItem($index)" class="w3-btn w3-padding w3-green">اعمال تغییرات</button></div><div class="w3-col s6"><input   placeholder="مبلغ سفارش را درج نمایید..." ng-model="editPriceMeValue" class="w3-input w3-border w3-padding" ></div></div></div>'
    };
});


app.directive("MyDirective", function() {
    return {
        restrict : "C", // <div class="MyDirective"></div>
        template : "<h1>Made by a directive!</h1>"
    };
});
