angular.module('uinsApp', ['simple-autocomplete']).controller('uinsCtrl', function($scope,$http) {
	$scope.selectedData = null;
	$scope.datas = [];

 $http({
        method: "GET",
        url: apiUrl+"allcompanies"
    }).then(function mySuccess(response) {
        $scope.companies = response.data;
		for(i in $scope.companies)
			$scope.datas.push({company: $scope.companies[i].company, id: $scope.companies[i].id});

    }, function myError(response) {
        $scope.companies = response.statusText;
    }

    );


	$scope.onSelect = function(selection) {
		console.log(selection);
		$scope.selectedData = selection;
	};

	$scope.clearInput = function() {
		$scope.$broadcast('simple-autocomplete:clearInput');
	};


	///////start//////

    function allOrdersShow() {
        $http({
            method: "GET",
            url: apiUrl +"allordertypes"
        }).then(function mySuccess(response) {
            $scope.ordertypes = response.data;
        }, function myError(response) {
            $scope.ordertypes = response.statusText;
        });


        $http({
            method: "GET",
            url: apiUrl +"allcompanies"
        }).then(function mySuccess(response) {
                $scope.companies = response.data;


            }, function myError(response) {
                $scope.companies = response.statusText;
            }


        );




        $http({
            method: "GET",
            url: Url
        }).then(function mySuccess(response) {
            $scope.products = response.data;

        }, function myError(response) {
            $scope.products = response.statusText;


        });

    }


    allOrdersShow();
    ////////////
///////Add////////////
    $scope.addItem = function () {
        $scope.errortext = "";
        if (!$scope.addMe) {return;}
        if ($scope.products.indexOf($scope.addMe) == -1) {

            $scope.products.push({ order_id: 1, order_value: $scope.addMe , type_id: $scope.addMeTypeId , instrument_id: $scope.addMeCompany ,instrument_name: $scope.addMeCompany , order_date: new Date().getYear() });
            ///////////////add item to db
            $.ajax({type:'Post',
                url:"http://localhost/leila7/public/uins/addAnOrder",
                data: {'typeId':$scope.addMeTypeId,
                    'orderValue':$scope.addMe,
                    'company':$scope.addMeCompany
                },
                success:function(data) {
                    if(data=="YES") {
                        rowElement.fadeOut().remove();
                    }else {
                    }}
            });
            ///////////end of add item to db


        } else {
            $scope.errortext = "The item is already in your shopping list.";
        }

    }
///////end of Add////////////
////////edit only price
    $scope.editThisPrice = function (x) {
        document.getElementById("editForm").style.display = "none";
        document.getElementById("editPriceForm").style.display = "block";
        document.getElementById("addForm").style.display = "none";
        $scope.editPriceMeValue =$scope.products[x].order_value;

        ///////Edit////////////
        $scope.editPriceItem = function () {
            $scope.errortext = "";
            ///////////////add item to db
            $.ajax({type:'Patch',
                url:"http://localhost/leila7/public/uins/editAnOrder",
                data: {'order_id':$scope.products[x].order_id,
                    'order_value':$scope.editPriceMeValue
                },
                success:function(data) {
                    if(data=="YES") {
                        rowElement.fadeOut().remove();
                    }else {
                    }}
            });
            ///////////end of add item to db


            $scope.products[x].order_value = $scope.editPriceMeValue;

            document.getElementById("editForm").style.display = "none";
            document.getElementById("editPriceForm").style.display = "none";
            document.getElementById("addForm").style.display = "block";
        }
///////end of Edit////////////
    }

//////end of edit only price

    $scope.editThisItem = function (x) {
        document.getElementById("editForm").style.display = "block";
        document.getElementById("editPriceForm").style.display = "none";
        document.getElementById("addForm").style.display = "none";
        $scope.editMeTypeId =$scope.products[x].type_id;
        $scope.editMeCompany =$scope.products[x].instrument_name;
        $scope.editMeValue =$scope.products[x].order_value;

        ///////Edit////////////
        $scope.editItem = function () {

            $scope.errortext = "";
            ///////////////add item to db
            $.ajax({type:'Put',
                url:"http://localhost/leila7/public/uins/putOrder",
                data: {'order_id':$scope.products[x].order_id,
                    'order_value':$scope.editMeValue,
                    'type_id':$scope.editMeTypeId,
                    'instrument_id':$scope.editMeCompany
                },
                success:function(data) {
                    if(data=="YES") {
                        rowElement.fadeOut().remove();
                    }else {
                    }}
            });
            ///////////end of add item to db
            $scope.products[x].order_value = $scope.editMeValue;
            $scope.products[x].instrument_name = $scope.editMeCompany;
            $scope.products[x].type_id = $scope.editMeTypeId;


            document.getElementById("editForm").style.display = "none";
            document.getElementById("editPriceForm").style.display = "none";
            document.getElementById("addForm").style.display = "block";
        }
///////end of Edit////////////
    }


    $scope.removeItem = function (x) {
        //////delete from db///////////////
        $http({
            method : "GET",
            url : "http://localhost/leila7/public/uins/deleteAnOrder?OrderId="+$scope.products[x].order_id
        }).then(function mySuccess(response) {
            $scope.products = response.data;
        }, function myError(response) {
            $scope.products = response.statusText;
            $scope.errortext = "هیچ موردی حذف نگردید.";

        });
        ////////end of delete from db//////

        $scope.errortext = "";
        $scope.products.splice(x, 1);


    }

    $scope.orderByMe = function(x) {
        $scope.myOrderBy = $scope.products[x].order_value;
    }


    $scope.greaterThan = function(prop, val){
        return function(item){
            return item[prop] < val;
        }
    }

    $scope.header = {
        title: 'مدیریت سفارشات'
    };

    // for(i in  $scope.companies )
    // {

    //  }
    $scope.companyNames = " Kishore relangi kumar nani suman srikanth vamsi".split(' ');



    ///////end//


})