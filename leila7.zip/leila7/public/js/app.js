var app = angular.module("uinsManagement", []);
var apiUrl = 'http://localhost/leila7/public/uins/';
var companies = [];
var Url;
Url = apiUrl + "allOrders";

