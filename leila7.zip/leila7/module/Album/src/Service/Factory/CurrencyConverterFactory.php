<?php

namespace Album\Service\Factory;

use Interop\Container\ContainerInterface;
use Zend\ServiceManager\Factory\FactoryInterface;
use Album\Service\CurrencyConverter;

class CurrencyConverterFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $service = new CurrencyConverter();

        return $service;
    }
}
