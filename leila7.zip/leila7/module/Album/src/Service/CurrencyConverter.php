<?php

namespace Album\Service;
use Zend\View\Model\JsonModel;

class CurrencyConverter
{
    /**
     *
     * @param int $amount
     */
    public function convertEURtoUSD($albumst)
    {


		
		
		
        $arr=array();
        foreach ($albumst as $albumt) :

                  array_push($arr,$albumt->id.':'.$albumt->title.':'.$albumt->artist);

         endforeach;
//$p2=json_decode($p1);
        return $arr;
    }
}
