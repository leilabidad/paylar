<?php

namespace Admin\Factory;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Admin\View\Helper\ControllerActionName;

class ControllerActionNameViewHelperFactory  {

    public function createService(ServiceLocatorInterface $serviceLocator) {
        $serviceManager = $serviceLocator->getServiceLocator();
        $routeMatch = $serviceManager->get('Application')->getMvcEvent()->getRouteMatch();
        return new ControllerActionName($routeMatch);
    }

    public function __invoke()
    {
        return;
    }
}