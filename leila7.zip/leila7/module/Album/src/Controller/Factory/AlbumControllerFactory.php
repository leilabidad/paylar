<?php
namespace Album\Controller\Factory;

use Album\Controller\AlbumController;
use Album\Model\AlbumTable;
use Interop\Container\ContainerInterface;
use Zend\ServiceManager\Factory\FactoryInterface;

// Factory class
class AlbumControllerFactory implements FactoryInterface
{
    public function __invoke( ContainerInterface $container, $requestedName, array $options = null)
    {
        $album          = $container->get(AlbumTable::class);
        $converter      = $container->get('CurrencyConverters');
        $entityManager  = $container->get('doctrine.entitymanager.orm_default');

        return new AlbumController(
            $album,
            $converter,
            $entityManager
        );
    }


}