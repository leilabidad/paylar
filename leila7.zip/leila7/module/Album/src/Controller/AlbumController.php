<?php
namespace Album\Controller;

use Album\Model\AlbumTable;
use Album\Service\CurrencyConverter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Album\Form\UinsForm;
use Album\Entity\AlbumEntity;

class AlbumController extends AbstractActionController
{

    /**
     * @var AlbumTable
     */
    private $table;

    /**
     * @var CurrencyConverter
     */
    protected $convert;

    protected $entityManager;

    public function __construct(
        AlbumTable $table,
        CurrencyConverter $convert,
        $entityManager
    )
    {
        $this->table            = $table;
        $this->convert          = $convert;
        $this->entityManager    = $entityManager;
    }

    public function indexAction()
    {


	

		if(isset($_POST['string']) && $_POST['string']!="") {

			// Create new Post entity.
			$albumEntity = new AlbumEntity();
			$albumEntity->setTitle($_POST['string']);
			$albumEntity->setArtist($_POST['string'] . '  Art bidad');

			// Add the entity to entity manager.
			$this->entityManager->persist($albumEntity);

			// Apply changes to database.
			$this->entityManager->flush();

		}
        return new ViewModel([
            'albums' => $this->table->fetchAll(),
            'service' => $this->convert->convertEURtoUSD($this->table->fetchAll()),
        ]);


        // Grab the paginator from the AlbumTable:
        $paginator = $this->table->fetchAll(true);

        // Set the current page to what has been passed in query string,
        // or to 1 if none is set, or the page is invalid:
        $page = (int) $this->params()->fromQuery('page', 1);
        $page = ($page < 1) ? 1 : $page;
        $paginator->setCurrentPageNumber($page);

        // Set the number of items per page to 10:
        $paginator->setItemCountPerPage(10);

        return new ViewModel(['paginator' => $paginator]);

    }

    /* Update the following method to read as follows: */
    public function addAction()
    {
        $form = new UinsForm();
        $form->get('submit')->setValue('Add');

        $request = $this->getRequest();

        if (! $request->isPost()) {
            return ['form' => $form];
        }

        $album = new Album();
        $form->setInputFilter($album->getInputFilter());
        $form->setData($request->getPost());

        if (! $form->isValid()) {
            return ['form' => $form];
        }

        $album->exchangeArray($form->getData());
        $this->table->saveAlbum($album);
        return $this->redirect()->toRoute('album');
    }

    /* ... */


    public function editAction()
    {
        $id = (int) $this->params()->fromRoute('id', 0);

        if (0 === $id) {
            return $this->redirect()->toRoute('album', ['action' => 'add']);
        }

        // Retrieve the album with the specified id. Doing so raises
        // an exception if the album is not found, which should result
        // in redirecting to the landing page.
        try {
            $album = $this->table->getAlbum($id);
        } catch (\Exception $e) {
            return $this->redirect()->toRoute('album', ['action' => 'index']);
        }

        $form = new UinsForm();
        $form->bind($album);
        $form->get('submit')->setAttribute('value', 'Edit');

        $request = $this->getRequest();
        $viewData = ['id' => $id, 'form' => $form];

        if (! $request->isPost()) {
            return $viewData;
        }

        $form->setInputFilter($album->getInputFilter());
        $form->setData($request->getPost());

        if (! $form->isValid()) {
            return $viewData;
        }

        $this->table->saveAlbum($album);

        // Redirect to album list
        return $this->redirect()->toRoute('album', ['action' => 'index']);
    }


    // Add content to the following method:
    public function deleteAction()
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('album');
        }

        $request = $this->getRequest();
        if ($request->isPost()) {
            $del = $request->getPost('del', 'No');

            if ($del == 'Yes') {
                $id = (int) $request->getPost('id');
                $this->table->deleteAlbum($id);
            }

            // Redirect to list of albums
            return $this->redirect()->toRoute('album');
        }

        return [
            'id'    => $id,
            'album' => $this->table->getAlbum($id),
        ];
    }



}



