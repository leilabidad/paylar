<?php
namespace Album;

use Album\Controller\Factory\AlbumControllerFactory;
use Album\Service\Factory\CurrencyConverterFactory;
use Zend\Router\Http\Segment;

return [
   'controllers' => [
        'factories' => [
            Controller\AlbumController::class => AlbumControllerFactory::class,
//            Controller\IndexController::class => Controller\Factory\IndexControllerFactory::class,
        ],
    ],

    // The following section is new and should be added to your file:
    'router' => [
        'routes' => [
            'album' => [
                'type'    => Segment::class,
                'options' => [
                    'route' => '/album[/:action[/:id]]',
                    'constraints' => [
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ],
                    'defaults' => [
                        'controller' => Controller\AlbumController::class,
                        'action' => 'index'
                    ],
                ],
            ],
        ],
    ],

    'service_manager' => [
        'factories' => [
            'CurrencyConverters' => CurrencyConverterFactory::class
        ],
    ],


    'view_manager' => [
        'template_path_stack' => [
            'album' => __DIR__ . '/../view',
        ],
    ],
];
