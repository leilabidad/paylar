<?php
namespace Blog\Controller;

use Blog\Model\BlogTable;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Blog\Form\BlogForm;
use Blog\Model\Blog;

class BlogController extends AbstractActionController
{
    private $table;

    public function __construct( BlogTable $table)
    {
        $this->table = $table;
    }



    public function indexAction()
    {
        return new ViewModel([
            'Blogs' => $this->table->fetchAll(),
        ]);


        // Grab the paginator from the BlogTable:
        $paginator = $this->table->fetchAll(true);

        // Set the current page to what has been passed in query string,
        // or to 1 if none is set, or the page is invalid:
        $page = (int) $this->params()->fromQuery('page', 1);
        $page = ($page < 1) ? 1 : $page;
        $paginator->setCurrentPageNumber($page);

        // Set the number of items per page to 10:
        $paginator->setItemCountPerPage(10);

        return new ViewModel(['paginator' => $paginator]);

    }

    /* Update the following method to read as follows: */
    public function addAction()
    {
        $form = new BlogForm();
        $form->get('submit')->setValue('Add');

        $request = $this->getRequest();

        if (! $request->isPost()) {
            return ['form' => $form];
        }

        $Blog = new Blog();
        $form->setInputFilter($Blog->getInputFilter());
        $form->setData($request->getPost());

        if (! $form->isValid()) {
            return ['form' => $form];
        }

        $Blog->exchangeArray($form->getData());
        $this->table->saveBlog($Blog);
        return $this->redirect()->toRoute('Blog');
    }

    /* ... */


    public function editAction()
    {
        $id = (int) $this->params()->fromRoute('id', 0);

        if (0 === $id) {
            return $this->redirect()->toRoute('Blog', ['action' => 'add']);
        }

        // Retrieve the Blog with the specified id. Doing so raises
        // an exception if the Blog is not found, which should result
        // in redirecting to the landing page.
        try {
            $Blog = $this->table->getBlog($id);
        } catch (\Exception $e) {
            return $this->redirect()->toRoute('Blog', ['action' => 'index']);
        }

        $form = new BlogForm();
        $form->bind($Blog);
        $form->get('submit')->setAttribute('value', 'Edit');

        $request = $this->getRequest();
        $viewData = ['id' => $id, 'form' => $form];

        if (! $request->isPost()) {
            return $viewData;
        }

        $form->setInputFilter($Blog->getInputFilter());
        $form->setData($request->getPost());

        if (! $form->isValid()) {
            return $viewData;
        }

        $this->table->saveBlog($Blog);

        // Redirect to Blog list
        return $this->redirect()->toRoute('Blog', ['action' => 'index']);
    }


    // Add content to the following method:
    public function deleteAction()
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('Blog');
        }

        $request = $this->getRequest();
        if ($request->isPost()) {
            $del = $request->getPost('del', 'No');

            if ($del == 'Yes') {
                $id = (int) $request->getPost('id');
                $this->table->deleteBlog($id);
            }

            // Redirect to list of Blogs
            return $this->redirect()->toRoute('Blog');
        }

        return [
            'id'    => $id,
            'Blog' => $this->table->getBlog($id),
        ];
    }



}



