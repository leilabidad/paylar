<?php
namespace User\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use DoctrineORMModule\Paginator\Adapter\DoctrinePaginator as DoctrineAdapter;
use Doctrine\ORM\Tools\Pagination\Paginator as ORMPaginator;
use Zend\Paginator\Paginator;

class IndexController extends AbstractActionController
{
    public function indexAction()
    {
        $viewModel = new ViewModel();

        $dispatchOutput = $this->forward()->dispatch(IndexController::class, array('action' => 'toInclude'));

        $viewModel->addChild($dispatchOutput, 'child1');

        return $viewModel;
    }

    public function toIncludeAction()
    {
        return new ViewModel();
    }
}