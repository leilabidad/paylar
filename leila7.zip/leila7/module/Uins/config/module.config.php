<?php
namespace Uins;

use Uins\Controller\Factory\UinsControllerFactory;
use Uins\Service\Factory\UserInstrumentFactory;
use Zend\Router\Http\Segment;
use Uins\View\Helper\ThumbnailsHelper;

return [
    'controllers' => [
        'factories' => [
            Controller\UinsController::class => UinsControllerFactory::class,
        ],
    ],

    'router' => [
        'routes' => [
            'uins' => [
                'type'    => Segment::class,
                'options' => [
                    'route' => '/uins[/:action[/:id]]',
                    'constraints' => [
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ],
                    'defaults' => [
                        'controller' => Controller\UinsController::class,
                        'action'     => 'index',
                    ],
                ],
            ],
        ],
    ],

    'service_manager' => [
        'factories' => [
            'UserInstrument' => UserInstrumentFactory::class,
            'Zend\Session\Config\ConfigInterface' => 'Zend\Session\Service\SessionConfigFactory'

        ],
    ],

    'view_manager' => [
        'template_path_stack' => [
            'uins' => __DIR__ . '/../view',
        ],
    ],

    // There are all helpers
    'view_helpers' => [
        'invokables' => [
            'ThumbnailsHelper' => ThumbnailsHelper::class
        ]
    ],

 
];