<?php
namespace Uins\Controller;

use Uins\Entity\InstrumentEntity;
use Uins\Service\UserInstrument;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Uins\Form\UinsLoginFormFieldset;
use Uins\Form\UinsRegisterFormFieldset;
use Uins\Form\UinsBuyFormFieldset;
use Uins\Form\UinsSaleFormFieldset;
use Uins\Form\UinsOrderFormFieldset;
use Uins\Form\UinsOrdersFilterFormFieldset;

use Uins\Filter\PhoneFilter;
use Zend\Db\Sql\Select;
use Zend\Validator\Db\RecordExists;

class UinsController extends AbstractActionController
{
    /**
     * @var UserInstrument
     */
    protected $UserInstruments;


    public function __construct(
        UserInstrument $UserInstruments
    )
    {
        $this->UserInstruments = $UserInstruments;

    }

    public function indexAction()
    {
        $user = null;
        $userInstrumentLogin = '';
        $formLogin = new UinsLoginFormFieldset();
        if ($this->getRequest()->isPost()) {
            $postUsername = $this->params()->fromPost('username', '');
            $postPassword = $this->params()->fromPost('password', '');
            $user = $this->UserInstruments->UserInstrumentLogin($postUsername, $postPassword);
            if ($user) {
                $userInstrumentLogin = 'welcome ' . $user['username'];
            } else {
                $userInstrumentLogin = 'user not found';
            }
        }

        if (!empty($user)) {
            $selectAllUserInstruments = $this->UserInstruments->selectAllUserInstruments($user);
            $selectAllInstruments = $this->UserInstruments->selectAllInstruments();
            return new ViewModel([
                'getAllUserInstrumentsRecords' => $selectAllUserInstruments,
                'UserInstrumentLogin' => $userInstrumentLogin,
                'IsUserLogin' => true,
                'allInstruments' => $selectAllInstruments,
                'currentUser' => $user
            ]);
        }

        return new ViewModel([
            'IsUserLogin' => false,
            'UserInstrumentLogin' => $userInstrumentLogin,
            'formLogin' => $formLogin
        ]);

    }

    public function buyAction()
    {

        $IsUserLogin = $this->UserInstruments->IsUserLogin();
        $notLogin = 'شما به این صفحه دسترسی ندارید';

        if ($IsUserLogin) {
            $postInstrument_id = $this->params()->fromPost('instrument_id', '');
            $postQuantity = $this->params()->fromPost('quantity', '');
            $selectAllInstruments = $this->UserInstruments->selectAllInstruments();
            $formBye = new UinsBuyFormFieldset($selectAllInstruments);

            if ($this->getRequest()->isPost()) {
                $act = 'Buy';
                $addUserInstriment = $this->UserInstruments->addUserInstriment($postInstrument_id, $postQuantity, $act);
            } else
                $addUserInstriment = '';

            return new ViewModel([
                'serviceUserInstrument' => $addUserInstriment,
                'allInstruments' => $selectAllInstruments,
                'IsUserLogin' => $IsUserLogin,
                'formBye' => $formBye,
            ]);
        } else
            return new ViewModel([
                'notLogin' => $notLogin,
            ]);

    }

    public function saleAction()
    {

        $IsUserLogin = $this->UserInstruments->IsUserLogin();
        $notLogin = 'شما به این صفحه دسترسی ندارید';

        if ($IsUserLogin) {
            $postInstrument_id = $this->params()->fromPost('instrument_id', '');
            $postQuantity = $this->params()->fromPost('quantity', '');
            $selectAllInstruments = $this->UserInstruments->selectAllInstruments();
            $formSale = new UinsSaleFormFieldset($selectAllInstruments);

            if ($this->getRequest()->isPost()) {
                $act = 'Sale';
                $addUserInstriment = $this->UserInstruments->addUserInstriment($postInstrument_id, $postQuantity, $act);
            } else
                $addUserInstriment = '';

            return new ViewModel([
                'serviceUserInstrument' => $addUserInstriment,
                'allInstruments' => $selectAllInstruments,
                'IsUserLogin' => $IsUserLogin,
                'formSale' => $formSale,
            ]);
        } else
            return new ViewModel([
                'notLogin' => $notLogin,
            ]);

    }


    public function editAction()
    {
    }

    public function deleteAction()
    {
    }

    public function registeruserAction()
    {

        $formRegister = new UinsRegisterFormFieldset();
        $postUsername = $this->params()->fromPost('username', '');
        $postPassword = $this->params()->fromPost('password', '');
        $postPhone = $this->params()->fromPost('phone', '');
        // Create PhoneFilter filter.
        $filter = new PhoneFilter();

        // Configure the filter.
        $filter->setFormat(PhoneFilter::PHONE_FORMAT_INTL);

        // Filter a string.
        $postPhone = $filter->filter($postPhone);

        if ($this->getRequest()->isPost())
            $UserInstrumentRegister = $this->UserInstruments->RegisterUser($postUsername, $postPassword, $postPhone);
        else
            $UserInstrumentRegister = '';

        return new ViewModel([
            'UserInstrumentRegister' => $UserInstrumentRegister,
            'formRegister' => $formRegister,
        ]);
    }


    public function logoutAction()
    {

        $session = new Container('User');
        $session->getManager()->destroy();

    }

    public function usersAction()
    {
        $AllUsers = '';
        return new ViewModel([
            'AllUsers' => $AllUsers,
        ]);
    }


    public function orderAction()
    {

        $IsUserLogin = $this->UserInstruments->IsUserLogin();

            $postInstrument_id = $this->params()->fromPost('instrument_id', '');
            $orderValue = $this->params()->fromPost('order_value', '');
            $postOrderType = $this->params()->fromPost('type_id', '');
            $selectAllInstruments = $this->UserInstruments->selectAllInstruments();
            $formOrder = new UinsOrderFormFieldset($selectAllInstruments);

            if ($this->getRequest()->isPost())
                $addUserInstriment = $this->UserInstruments->order($postInstrument_id, $orderValue, $postOrderType);
            else
                $addUserInstriment = '';

            return new ViewModel([
                'serviceUserInstrument' => $addUserInstriment,
                'allInstruments' => $selectAllInstruments,
                'IsUserLogin' => $IsUserLogin,
                'OrderType' => $postOrderType,
                'formOrder' => $formOrder,
            ]);


    }


    public function filterAction()
    {
        $request = $this->getRequest();
        $method= $request->getMethod();

        


        $companies = [];
        $instruments = $this->UserInstruments->selectAllInstruments();
        foreach ($instruments as $instrument)
            $companies[] = $instrument->company;

        $formFilter = new UinsOrdersFilterFormFieldset();
        return new ViewModel([
            'companies' => $companies,
            'formFilter' => $formFilter
        ]);

    }

    /**
     * return company from by filter
     */
    public function searchAction()
    {
        $company = $this->params()->fromQuery('company', null);
        $fromValue = $this->params()->fromQuery('fromValue', null);
        $toValue = $this->params()->fromQuery('toValue', null);

        if (empty($company)) {
            return $this->returnJsonResponse([
                'done' => false,
                'message' => 'company is req'
            ]);
        }

        elseif (empty($fromValue)) {
            if ($fromValue == 0) {
                return $this->returnJsonResponse([
                    'done' => false,
                    'message' => 'from value > 0'
                ]);
            }
            return $this->returnJsonResponse([
                'done' => false,
                'message' => 'from value is req'
            ]);
        }

        elseif (empty($toValue)) {
            return $this->returnJsonResponse([
                'done' => false,
                'message' => 'to value is req'
            ]);
        }

       else {
           $recordsResult=$this->UserInstruments->filterOrder($fromValue,$toValue,$company);
            return $this->returnJsonResponse($recordsResult);
       }


    }


    public function ordersAction()
    {
        $view = new ViewModel();

        $companies = [];
        $instruments = $this->UserInstruments->selectAllInstruments();
        foreach ($instruments as $instrument)
            $companies[] = $instrument->company;
        $view->setVariable('companies', $companies);

        return $view;
    }

    public function updateAction()

    {
        $request = $this->getRequest();
        $view = new ViewModel();
        $order_id=$this->params()->fromQuery('order_id', 'default_val');
        $order_value = $this->params()->fromQuery('value', 'default_val');
        $order_date = $this->params()->fromPost('order_date', '');
        $instrument_id = $this->params()->fromPost('instrument_id', '');

        $this->UserInstruments->updateOrder($order_id, $order_value, $order_date,$instrument_id);
        $companies = [];
        $instruments = $this->UserInstruments->selectAllInstruments();
        foreach ($instruments as $instrument)
            $companies[] = $instrument->company;

        $method=$request->getMethod().' روش ارسال'.$_GET['tr'];
        $view->setVariable('vl', $order_value);

        $view->setVariable('method', $method);
        return $view;

    }



    private function returnJsonResponse($result)
    {
        $response = $this->getResponse();
        $response->getHeaders()->addHeaderLine( 'Content-Type', 'application/json' );
        $response->setContent(json_encode($result));
        return $response;
    }



    /**
     * delete order
     */
    public function deleteAnOrderAction()
    {
        $id = $this->params()->fromQuery('OrderId', '');
        $this->UserInstruments->deleteOrder($id);
        return $this->returnJsonResponse([
            'done' => true,
            'message' => 'done!'
        ]);
    }


    public function allordersAction()
    {


        $orderId = $this->params()->fromQuery('orderId', null);

        if($orderId)
            $recordsResult = $this->UserInstruments->selectAnOrder($orderId);
        else

            $recordsResult = $this->UserInstruments->selectAllOrders();
            return $this->returnJsonResponse($recordsResult);

    }




    public function addAnOrderAction()
    {
        $companyName = $this->params()->fromPost('company', '');
        $orderValue = $this->params()->fromPost('orderValue', '');
        $postOrderType = $this->params()->fromPost('typeId', '');

        if ($this->getRequest()->isPost())
             $this->UserInstruments->order($companyName, $orderValue, $postOrderType);

        return $this->returnJsonResponse([
            'done' => true,
            'message' =>'done'
        ]);

    }


    public function editAnOrderAction()

    {

        $data =  file_get_contents('php://input');
        $datas=explode("&",$data);
        $order_id=explode("=",$datas[0])[1];
        $order_value=explode("=",$datas[1])[1];

        $this->UserInstruments->updateOrder($order_id, $order_value);

        return $this->returnJsonResponse([
           'done' => true,
            'message' =>'done'
       ]);

    }

    public function putOrderAction()
    {

        $data =  file_get_contents('php://input');
        $datas=explode("&",$data);
        $order_id=explode("=",$datas[0])[1];
        $order_value=explode("=",$datas[1])[1];
        $OrderType=explode("=",$datas[2])[1];
        $InstrumentId=explode("=",$datas[3])[1];

        $this->UserInstruments->putOrder($order_id, $order_value,$OrderType,$InstrumentId);
        return $this->returnJsonResponse([
            'done' => true,
            'message' => 'done!'
        ]);

    }

    public function allCompaniesAction()
    {

        $companyName = $this->params()->fromQuery('companyId', null);
            if($companyName)
                $recordResult = $this->UserInstruments->getCompanyNameById($companyName);
            else
                $recordResult = $this->UserInstruments->selectAllInstruments();

        return $this->returnJsonResponse($recordResult);

    }

    public function allOrderTypesAction()
    {

            $recordsResult = $this->UserInstruments->selectAllOrderTypes();
        return $this->returnJsonResponse($recordsResult);

    }


    public function myangularAction()
    {}
}
