<?php
namespace Uins\Controller\Factory;

use Uins\Controller\UinsController;
use Interop\Container\ContainerInterface;
use Zend\ServiceManager\Factory\FactoryInterface;

class UinsControllerFactory implements FactoryInterface
{
    public function __invoke( ContainerInterface $container, $requestedName, array $options = null)
    {
        $UserInstruments      = $container->get('UserInstrument');

        return new UinsController($UserInstruments);
    }
}