<?php
namespace Uins\Form;

use Zend\Form\Form;

class UinsOrdersFilterFormFieldset extends Form
{

    public function __construct($name = null)
    {
        // We will ignore the name provided to the constructor
        parent::__construct('uins');


        $arrayAllTypes=[
            '1' => 'خرید',
            '2' => 'فروش'
        ];

        $this->add([
            'name' => 'order_id',
            'type' => 'hidden',
        ]);

        $this->add([
            'name' => 'type_id',
            'type' => 'select',
            'options' => [
                'label' => 'انتخاب نوع',
                'value_options' => $arrayAllTypes,
            ],
        ]);

        $this->add([
            'name' => 'instrument_id',
            'attributes' => [         // Array of attributes
                'id'  => 'company',
            ],
            'type' => 'text',
            'options' => [
                'label' => 'از نام شرکت',
            ],
        ]);

        $this->add([
            'name' => 'from_value',
            'attributes' => [         // Array of attributes
                'id'  => 'fromValue',
            ],
            'type' => 'number',
            'options' => [
                'label' => 'از مبلغ',
            ],
        ]);

        $this->add([
            'name' => 'to_value',
            'attributes' => [         // Array of attributes
                'id'  => 'toValue',
            ],
            'type' => 'number',
            'options' => [
                'label' => 'تا مبلغ',
            ],
        ]);

        $this->add([
            'name' => 'from_date',
            'type' => 'date',
            'options' => [
                'label' => 'از تاریخ',
            ],
        ]);

        $this->add([
            'name' => 'to_date',
            'type' => 'date',
            'options' => [
                'label' => 'تا تاریخ',
            ],
        ]);

        $this->add([
            'name' => 'فیلتر',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id'    => 'submitbutton',
            ],
        ]);
    }
}