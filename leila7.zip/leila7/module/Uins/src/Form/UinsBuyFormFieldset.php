<?php
namespace Uins\Form;

use Zend\Form\Form;

class UinsBuyFormFieldset extends Form
{
    public $param;

    public function __construct($param)
    {
        // We will ignore the name provided to the constructor
        parent::__construct('uins');

        $this->add([
            'name' => 'id',
            'type' => 'hidden',
        ]);

        $this->param = $param;
        $arrayAllInstruments=[];

        foreach ($this->param as $key => $instrument) {
            $arrayAllInstruments[$instrument->id]=$instrument->company;
        }

        $this->add([
            'name' => 'instrument_id',
            'type' => 'select',
            'options' => [
                'label' => 'انتخاب شرکت',
                'value_options' => $arrayAllInstruments,
            ],
        ]);

        $this->add([
            'name' => 'quantity',
            'type' => 'number',
            'options' => [
                'label' => 'مبلغ',
            ],
        ]);
        $this->add([
            'name' => 'adduins',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id'    => 'submitbutton',
            ],
        ]);
    }
}