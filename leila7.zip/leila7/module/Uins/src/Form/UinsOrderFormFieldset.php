<?php
namespace Uins\Form;

use Zend\Form\Form;

class UinsOrderFormFieldset extends Form
{
    public $param;

    public function __construct($param)
    {
        // We will ignore the name provided to the constructor
        parent::__construct('uins');

        $this->param = $param;
        $arrayAllInstruments=[];
        $arrayAllTypes=[
            '1' => 'خرید',
            '2' => 'فروش'
        ];
        foreach ($this->param as $key => $instrument) {
            $arrayAllInstruments[$instrument->id]=$instrument->company;
        }

        $this->add([
            'name' => 'order_id',
            'type' => 'hidden',
        ]);

        $this->add([
            'name' => 'type_id',
            'id' => 'type_id',
            'type' => 'select',
            'attributes' => [
                'id'    => 'type_id',
            ],
            'options' => [
                'label' => 'انتخاب نوع',
                'value_options' => $arrayAllTypes,
            ],
        ]);

        $this->add([
            'name' => 'instrument_id',
            'id' => 'instrument_id',
            'type' => 'select',
            'attributes' => [
                'id'    => 'instrument_id',
            ],
            'options' => [
                'label' => 'انتخاب شرکت',
                'value_options' => $arrayAllInstruments,
            ],
        ]);

        $this->add([
            'name' => 'order_value',
            'type' => 'number',
            'attributes' => [
                'id'    => 'order_value',
            ],
            'options' => [
                'label' => 'مبلغ',
            ],
        ]);
        $this->add([
            'name' => 'order',
            'type' => 'submit',

            'attributes' => [
                'value' => 'Go',
                'id'    => 'submitbutton',
                'onclick'    => 'addOrder()',

            ],
        ]);
    }
}