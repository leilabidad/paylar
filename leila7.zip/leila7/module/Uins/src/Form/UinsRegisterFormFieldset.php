<?php
namespace Uins\Form;

use Zend\Form\Form;
use Uins\Filter\PhoneFilter;

class UinsRegisterFormFieldset extends Form
{
    public function __construct($name = null)
    {
        // We will ignore the name provided to the constructor
        parent::__construct('uins');

        $this->add([
            'name' => 'user_id',
            'type' => 'hidden',
        ]);
        $this->add([
            'name' => 'username',
            'type' => 'text',
            'options' => [
                'label' => 'نام کاربری',
            ],
        ]);
        $this->add([
            'name' => 'password',
            'type' => 'password',
            'options' => [
                'label' => 'رمز عبور',
            ],
        ]);
        $this->add([
            'name' => 'registernewuser',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id'    => 'submitbutton',
            ],
        ]);

        $this->add([
            'name'     => 'phone',
            'type' => 'text',
            'options' => [
                'label' => 'تلفن ثابت',
            ],
            'required' => true,
            'filters'  => [
                [
                    'name' => PhoneFilter::class,
                    'options' => [
                        'format' => PhoneFilter::PHONE_FORMAT_INTL
                    ]
                ],
                // ...
            ],
            // ...
        ]);

    }
}