<?php
namespace Uins\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * This class represents instruments for users.
 * @ORM\Entity
 * @ORM\Table(name="instrument")
 */
class InstrumentEntity
{

    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(name="id")
     */
    public $id;

    /**
     * @ORM\Column(name="company")
     */
    public $company;

    /**
     * @ORM\Column(name="price")
     */
    protected $price;

    /**
     * @ORM\Column(name="volume")
     */
    protected $volume;


    public function __construct()
    {
        $this->tags = new ArrayCollection();
    }

    // Returns ID of this company.
    public function getId()
    {
        return $this->id;
    }

    // Sets ID of this company.
    public function setId($id)
    {
        $this->id = $id;
    }

    // Returns company.
    public function getCompany()
    {
        return $this->company;
    }

    // Sets company.
    public function setCompany($company)
    {
        $this->company = $company;
    }

    // Returns price.
    public function getPrice()
    {
        return $this->price;
    }

    // Sets price.
    public function setPrice($price)
    {
        $this->price = $price;
    }

    //Returns volume.
    public function getVolume()
    {
        return $this->volume;
    }

    //Sets volume.
    public function setVolume($volume)
    {
        $this->volume=$volume;
    }

}