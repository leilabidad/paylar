<?php
namespace Uins\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * This class represents users instruments.
 * @ORM\Entity
 * @ORM\Table(name="orders")
 */
class OrdersEntity
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(name="order_id")
     */
    public $order_id;

    /**
     * @ORM\Column(name="type_id")
     */
    public $type_id;

    /**
     * @ORM\Column(name="user_id")
     */
    public $user_id;

    /**
     * @ORM\Column(name="instrument_id")
     */
    public $instrument_id;


    /**
     * @ORM\Column(name="order_value")
     */
    public $order_value;

    /**
     * @ORM\Column(name="order_date")
     */
    public $order_date;

    // Returns Order_id of a user instrument.
    public function getOrderId()
    {
        return $this->order_id;
    }

    // Sets ID of this user instrument.
    public function setOrderId($order_id)
    {
        $this->order_id = $order_id;
    }


    /**
     * @return mixed $user_id
     */

    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @param mixed $user_id
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }


    /**
     * @return mixed $instrument_id
     */
     public function getInstrumentId()
     {
        return $this->instrument_id;
     }

    /**
     * @param mixed $instrument_id
     */
    public function setInstrumentId($instrument_id)
    {
        $this->instrument_id = $instrument_id;
    }


    // Returns QUANTITY of a user instrument.
    public function getOrderValue()
    {
        return $this->order_value;
    }

    // Sets QUANTITY of this user instrument.
    public function setOrderValue($order_value)
    {
        $this->order_value = $order_value;
    }

    // Returns type of a user order.
    public function getTypeId()
    {
        return $this->type_id;
    }

    // Sets QUANTITY of this user instrument.
    public function setTypeId($type_id)
    {
        $this->type_id = $type_id;
    }


    // Returns type of a user order.
    public function getDate()
    {
        return $this->order_date;
    }

    // Sets QUANTITY of this user instrument.
    public function setDate($order_date)
    {
        $this->order_date = $order_date;
    }

}