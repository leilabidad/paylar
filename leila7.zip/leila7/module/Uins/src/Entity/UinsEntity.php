<?php
namespace Uins\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * This class represents users instruments.
 * @ORM\Entity
 * @ORM\Table(name="uins")
 */
class UinsEntity
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(name="id")
     */
    public $id;

    /**
     * @ORM\Column(name="user_id")
     */
    public $user_id;

    /**
     * @ORM\Column(name="instrument_id")
     */
    public $instrument_id;


    /**
     * @ORM\Column(name="quantity")
     */
    public $quantity;

    // Returns ID of a user instrument.
    public function getId()
    {
        return $this->id;
    }

    // Sets ID of this user instrument.
    public function setId($id)
    {
        $this->id = $id;
    }


    /**
     * @return mixed $user_id
     */

    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @param mixed $user_id
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }


    /**
     * @return mixed $instrument_id
     */
     public function getInstrumentId()
     {
        return $this->instrument_id;
     }

    /**
     * @param mixed $instrument_id
     */
    public function setInstrumentId($instrument_id)
    {
        $this->instrument_id = $instrument_id;
    }


    // Returns QUANTITY of a user instrument.
    public function getQuantity()
    {
        return $this->quantity;
    }

    // Sets QUANTITY of this user instrument.
    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;
    }

}