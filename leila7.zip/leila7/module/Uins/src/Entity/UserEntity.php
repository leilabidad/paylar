<?php
namespace Uins\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * This class represents instruments for users.
 * @ORM\Entity
 * @ORM\Table(name="user")
 */
class UserEntity
{

    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(name="user_id")
     */
    public $user_id;

    /**
     * @ORM\Column(name="username")
     */
    protected $username;

    /**
     * @ORM\Column(name="password")
     */
    protected $password;

    /**
     * @ORM\Column(name="amount")
     */
    protected $amount;

    /**
     * @ORM\Column(name="phone")
     */
    protected $phone;

    // Returns USER_ID of this user.
    public function getUserId()
    {
        return $this->user_id;
    }

    // Sets USER_ID of this user.
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }

    // Returns username.
    public function getUsername()
    {
        return $this->username;
    }

    // Sets username.
    public function setUsername($username)
    {
        $this->username = $username;
    }


    // Returns password.
    public function getPassword()
    {
        return $this->password;
    }

    // Sets password.
    public function setPassword($password)
    {
        $this->password = $password;
    }

    //Returns amount.
    public function getAmount()
    {
        return $this->amount;
    }

    //Sets amount.
    public function setAmount($amount)
    {
        $this->amount=$amount;
    }

    //Returns phone.
    public function getPhone()
    {
        return $this->phone;
    }

    //Sets phone.
    public function setPhone($phone)
    {
        $this->phone=$phone;
    }
}