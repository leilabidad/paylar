<?php
namespace Uins\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * This class represents instruments for users.
 * @ORM\Entity
 * @ORM\Table(name="order_types")
 */
class OrderTypeEntity
{

    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(name="id")
     */
    public $id;

    /**
     * @ORM\Column(name="type_name")
     */
    public $type_name;


    public function __construct()
    {
        $this->tags = new ArrayCollection();
    }

    // Returns ID of this company.
    public function getId()
    {
        return $this->id;
    }

    // Sets ID of this company.
    public function setId($id)
    {
        $this->id = $id;
    }

    // Returns Type Name.
    public function getTypeName()
    {
        return $this->type_name;
    }

    // Sets Type Name.
    public function setTypeName($type_name)
    {
        $this->type_name = $type_name;
    }

}