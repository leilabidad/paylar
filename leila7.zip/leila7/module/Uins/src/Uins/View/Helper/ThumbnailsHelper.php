<?php
namespace Uins\View\Helper;
use Zend\Filter\Boolean;
use Zend\View\Helper\AbstractHelper;

class ThumbnailsHelper extends AbstractHelper
{
    /**
     * @param array $thumbnails
     * @param bool $withLinks
     * @return string
     */

    public function __invoke(array $thumbnails, Boolean $withLinks = false)
{
$code = '<div class="thumbnailsGrid">';
    foreach ($thumbnails as $thumbnail) {
    $code .= '</div>';

if ($withLinks) {
$code .= '<a href="' . $thumbnail['link'] . '">';
    }
    $code .= '<img src="' . $thumbnail['img'] . '" alt="' . $thumbnail['name'] . '" />';
    if ($withLinks) {
    $code .= '</a>';
}

$code .= '</div>';
}
$code .= '</div>';

return $code;
}
}
