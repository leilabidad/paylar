<?php
namespace Uins\Service;

use Uins\Entity\OrderTypeEntity;
use Uins\Entity\UserEntity;
use Uins\Entity\UinsEntity;
use Uins\Entity\OrdersEntity;
use Uins\Entity\InstrumentEntity;
use Zend\Session\Container;
use Zend\Db\Sql\Select;
use Zend\Db\Adapter\AdapterInterface;

class UserInstrument
{
    /**
     * @param $entityManager
     * @param $username
     * @return mixed
     */
    protected $entityManager;

    public function __construct(
        $entityManager
    )
    {
        $this->entityManager            = $entityManager;

    }

    // Get current online UserId field.
    public function getCurrentUser($username)
    {
        $userEntity = $this->entityManager->getRepository(UserEntity::class)
            ->findOneBy([
                'username' =>  $username
            ]);

        return($userEntity->getUserId());
    }
    private function returnCompanyId($companyName)
    {

        $instrumentEntity = $this->entityManager->getRepository(InstrumentEntity::class)
            ->findOneBy([
                'company' =>  $companyName
            ]);



        $instrumentCompany=$instrumentEntity->id;

        return($instrumentCompany);

    }

    public function order($companyName,$orderValue,$orderType)
    {


        $session = new Container('User');
        $username= $session->offsetGet('username');
        $result=$username." عزیز! خوش آمدید!";
        $userEntity = $this->entityManager->getRepository(UserEntity::class)
            ->findOneBy([
                'username' =>  $username
            ]);

        $companyId = $this->returnCompanyId($companyName);
        $user_id = $userEntity->getUserId();

        $timestamp = time();
        $datetimeFormat = 'Y-m-d H:i:s';

        $date = new \DateTime();
        $date->setTimestamp($timestamp);
        $dateNow= $date->format($datetimeFormat);

        // Create new User instrument entity.
        $ordersEntity = new OrdersEntity();
        $ordersEntity->setInstrumentId($companyId);
        $ordersEntity->setUserId($user_id);
        $ordersEntity->setOrderValue($orderValue);
        $ordersEntity->setTypeId($orderType);
        $ordersEntity->setDate($dateNow);

        //Checking the value is empty or not

                $this->entityManager->persist($ordersEntity);


            // Apply changes to database.
            $this->entityManager->flush();


        return;
    }
    public function addUserInstriment($instrument_id,$quantity,$act)
    {

        $session = new Container('User');
        $username= $session->offsetGet('username');
        $result=$username." عزیز! خوش آمدید!";
        $userEntity = $this->entityManager->getRepository(UserEntity::class)
            ->findOneBy([
                'username' =>  $username
            ]);
        $user_id = $userEntity->getUserId();

        // Create new User instrument entity.
        $uinsEntity = new UinsEntity();
        $uinsEntity->setInstrumentId($instrument_id);
        $uinsEntity->setUserId($user_id);
        $uinsEntity->setQuantity($quantity);
        $userInstrumentRecordExist=false;
        $validatorUserInstrument = new \DoctrineModule\Validator\ObjectExists([
            'object_repository' => $this->entityManager->getRepository(UinsEntity::class),
            'fields' => ['user_id','instrument_id'],
        ]);

        if($validatorUserInstrument->isValid([$user_id,$instrument_id]))
            $userInstrumentRecordExist=true;

        //Checking the value is empty or not
        if(($quantity!="")  )
            {
                 // Find existing User Instrument record in uins table of database.If record not exist it will be added to uins table
                 if($userInstrumentRecordExist==false)
                     $this->entityManager->persist($uinsEntity);

                 //else the exiested record will be edited
                 else
                    $uinsEntity = $this->entityManager->getRepository(UinsEntity::class)
                            ->findOneBy([
                                'user_id' =>  $user_id,
                                'instrument_id' =>  $instrument_id
                            ]);

                 // Find existing post in the database.
                 $instrumentEntity = $this->entityManager->getRepository(InstrumentEntity::class)
                         ->findOneById($instrument_id);
                 $instrumentEntity->setVolume($instrumentEntity->getVolume()+$quantity);
                    // Find existing post in the database.
                 $userEntity = $this->entityManager->getRepository(userEntity::class)
                         ->find([
                             'user_id' =>  $user_id
                         ]);
                 if($act=='Buy')
                     {
                         $userEntity->setAmount($userEntity->getAmount()+$quantity);
                         if($userInstrumentRecordExist)
                             $uinsEntity->setQuantity($uinsEntity->getQuantity()+$quantity);
                         $result.= "خرید با موفقیت انجام شد!";
                     }
                 elseif($act=='Sale')
                     {
                         $userEntity->setAmount($userEntity->getAmount()-$quantity);
                         if($userInstrumentRecordExist)
                         {
                             if(($uinsEntity->getQuantity()>$quantity) || ($uinsEntity->getQuantity()==$quantity))
                             {
                                 $uinsEntity->setQuantity($uinsEntity->getQuantity() - $quantity);
                                 $result.= "فروش با موفقیت انجام شد!";
                             }
                             else
                                 $result.= "موجودی شما برای فروش در این شرکت کافی نمی باشد!";
                         }
                     }

                 // Apply changes to database.
                $this->entityManager->flush();
            }
        else
            $result.= "";

        return $result;
    }

    public function selectAllInstruments()
    {
        $instruments = $this->entityManager->getRepository(InstrumentEntity::class)->findAll();
        return $instruments;
    }

    public function selectAllOrderTypes()
    {
        $orderTypeEntity = $this->entityManager->getRepository(OrderTypeEntity::class)->findAll();
        return $orderTypeEntity;
    }


    public function selectAllOrders()
    {
        $session = new Container('User');
        $username= $session->offsetGet('username');
        $userId = $this->getCurrentUser($username);
        $orders = $this->entityManager->getRepository(OrdersEntity::class)
            ->findBy([
                'user_id' =>  $userId
            ]);

        foreach ($orders as $order)
        {
            foreach ($this->selectAllInstruments() as $ins)
            {
                if($order->instrument_id==$ins->id)
                    $order->instrument_name=$ins->company;
            }

            foreach ($this->selectAllOrderTypes() as $type)
            {
                if($order->type_id==$type->id)
                    $order->type_name=$type->type_name;
            }
        }
        return $orders;
    }

    public function selectAnOrder($id)
    {
        $order = $this->entityManager->getRepository(OrdersEntity::class)
            ->findOneBy([
                'order_id' => $id
            ]);

        return $order;
    }
    public function selectAllUserInstruments($user)
    {
        $username = $user['username'];
        if($username != '') {
            //Findig current user_id
            $userEntity = $this->entityManager->getRepository(UserEntity::class)
                ->findOneBy([
                    'username' => $username
                ]);

            if(!empty($userEntity)) {
                $uinsEntity = $this->entityManager->getRepository(uinsEntity::class)
                    ->findBy([
                        'user_id' => $userEntity->getUserId()
                    ]);
                return $uinsEntity;
            } else {
                return null;
            }
        }
        return null;
    }

    //Login User.
    public function UserInstrumentLogin($username,$password)
    {
        $userRecordExist=false;
        // Create new User  entity.
        $userEntity = new UserEntity();
        $userEntity->setUsername($username);
        $userEntity->setPassword($password);
        //Checking user is online or not
        $validatorUsernamePassword = new \DoctrineModule\Validator\ObjectExists([
            'object_repository' => $this->entityManager->getRepository(UserEntity::class),
            'fields' => ['username','password'],
        ]);
        if($validatorUsernamePassword->isValid([$username,$password])) {
            $session = new Container('User');
            $session->username = $username;
            $session->password = $password;
        }
        return $this->getUser();
    }

    //Registering new user
    public function RegisterUser($username,$password,$phone)
    {
        $result='';

        // Create new User  entity.
        $userEntity = new UserEntity();
        $userEntity->setUsername($username);
        $userEntity->setPassword($password);
        $userEntity->setPhone($phone);
        $userEntity->setAmount(0);

        //Checking the user is exist or not
        $userExist=false;
        $validatorUser = new \DoctrineModule\Validator\ObjectExists([
            'object_repository' => $this->entityManager->getRepository(UserEntity::class),
            'fields' => ['username'],
        ]);
        if(( ($validatorUser->isValid([$username]))))
            $userExist=true;

        if($userExist==false)
            {
                $this->entityManager->persist($userEntity); //if record not exist it will be added to uins table
                $this->entityManager->flush();
                $result.= 'کاربری ثبت نام گردید';
            }
        else
            $result.=  'نام کاربری تکراری می باشد!';
        if($username=='')
            {
                $result.=  'نام کاربری خالی میباشد!';

            }
        if ($password=='')
            {
                $result.=  'رمز عبور خالی میباشد.';

            }

       return $result;
    }

     //Is any user login or not.
    public function IsUserLogin()
    {
        $userIsonline=false;

        //Checking user is online or not
        $validatorUsernamePassword = new \DoctrineModule\Validator\ObjectExists([
            'object_repository' => $this->entityManager->getRepository(UserEntity::class),
            'fields' => ['username','password'],
        ]);
        $session = new Container('User');
       if( ($session->offsetGet('username')!='') && ($session->offsetGet('password')!='') );
        {
            if ($validatorUsernamePassword->isValid([$session->offsetGet('username'), $session->offsetGet('password')]))
                $userIsonline = true;
        }
        return $userIsonline;

    }

    public function getUser()
    {
        $session = new Container('User');
        if($session->offsetGet('username')) {
            return [
                'username' => $session->offsetGet('username')
            ];
        }
        return null;
    }

    public function AllUsers()
    {
        $instruments = $this->entityManager->getRepository(InstrumentEntity::class)->findAll();
        return $instruments;
    }


    public function getAllOrders($fromValue,$toValue,$fromDate,$toDate,$instrumentCompany)
    {

        $qb = $this->entityManager->createQueryBuilder();
        $qb->select('s')
            ->from(OrdersEntity::class, 's');
        $query = $qb->getQuery();
        $result = $query->getResult();
        return $result;
    }


    public function getCompanyNameById($companyId)
    {
        $instrumentEntity = $this->entityManager->getRepository(InstrumentEntity::class)
            ->findOneBy([
                'id' =>  $companyId
            ]);
        return($instrumentEntity);
    }
    public function getOrder($fromValue,$toValue,$fromDate,$toDate,$instrumentCompany)
    {

        $instrumentEntity = $this->entityManager->getRepository(InstrumentEntity::class)
            ->findOneBy([
                'company' =>  $instrumentCompany
            ]);

        $instrumentCompany=$instrumentEntity->id;

        $qb = $this->entityManager->createQueryBuilder();



        if(($fromDate==null) && ($toDate==null)&& ($fromValue>0) && ($toValue>0))
            {
                $qb->select('s')
                    ->from(OrdersEntity::class, 's')
                    ->where('s.order_value>' . $fromValue)
                    ->andWhere('s.order_value<' . $toValue)
                    ->andWhere('s.instrument_id=' . $instrumentCompany)
                ;
            }

        elseif(($fromDate==null) && ($toDate==null)&& ($fromValue>0) && ($toValue==0))
        {
            $qb->select('s')
                ->from(OrdersEntity::class, 's')
                ->where('s.order_value>' . $fromValue)
                ->andWhere('s.instrument_id=' . $instrumentCompany);
        }
        elseif(($fromDate==null) && ($toDate==null)&& ($fromValue==0) && ($toValue>0))
        {
            $qb->select('s')
                ->from(OrdersEntity::class, 's')
                ->where('s.order_value<' . $toValue)
                ->andWhere('s.instrument_id=' . $instrumentCompany);
        }
        $query = $qb->getQuery();
        $result = $query->getResult();
        return count($result);
    }

    public function updateOrder($orderId,$value)
    {
        //echo "orderId- ".$orderId." </br>value-".$value; exit();
        $qb = $this->entityManager->createQueryBuilder();
        $query = $qb->update(OrdersEntity::class, 'a')->set('a.order_value', $qb->expr()->literal($value))->where('a.order_id = :order_id')->setParameter('order_id', $orderId)->getQuery();
       // $query = $qb->update(InstrumentEntity::class, 'a')->set('a.company', $qb->expr()->literal('اهدف من'))->where('a.id = :id')->setParameter('id', 3)->getQuery();

        $query->execute();


    }

    public function deleteOrder($orderId)
        {
            $instrumentEntity = $this->entityManager->getRepository(OrdersEntity::class)
                ->findOneBy([
                    'order_id' =>  $orderId
                ]);
            $this->entityManager->remove($instrumentEntity);
            $this->entityManager->flush();
        }



    public function filterOrder($fromValue,$toValue,$company)
    {

        $instrumentEntity = $this->entityManager->getRepository(InstrumentEntity::class)
            ->findOneBy([
                'company' =>  $company
            ]);

        $instrumentCompany=$instrumentEntity->id;
        $qb = $this->entityManager->createQueryBuilder();
        $qb->select('s')
            ->from(OrdersEntity::class, 's')
            ->where('s.order_value>' . $fromValue)
            ->andWhere('s.order_value<' . $toValue)
            ->andWhere('s.instrument_id=' . $instrumentCompany);

        $query = $qb->getQuery();
        $result = $query->getResult();
        return $result;
    }

    public function putOrder($orderId,$value,$orderTypeId,$companyName)
    {
        $instrumentEntity = $this->entityManager->getRepository(InstrumentEntity::class)
            ->findOneBy([
                'company' =>  $companyName
            ]);

        $instrumentEntity = $this->entityManager->getRepository(InstrumentEntity::class)
            ->findOneBy([
                'company' =>  $companyName
            ]);

        $instrument_id=$instrumentEntity->id;


        //$instrument_id=$instrumentEntity->getId();
        //$instrument_id=3;
        $qb = $this->entityManager->createQueryBuilder();
        $query = $qb->update(OrdersEntity::class, 'a')->set('a.order_value', $qb->expr()->literal($value))->set('a.type_id', $qb->expr()->literal($orderTypeId))->set('a.instrument_id', $qb->expr()->literal($instrument_id))->where('a.order_id = :order_id')->setParameter('order_id', $orderId)->getQuery();

        $query->execute();


    }

}
